====================================================
  DevGlobalJobs - VPS Update Package
  devglobaljobs.com
====================================================

CHANGES INCLUDED:
-----------------
1. Jobs Limit: Featured Jobs + All Jobs → 500 (was 20/30)
2. Grow Installation Script added to index.html
3. Google Auth Sign-In Box - Professional styling
4. NGO Free Posting Banner - Theme matched styling
5. Job Posting auth prompt - Professional styling

HOW TO DEPLOY:
--------------
Step 1: Upload this zip to your VPS
        e.g. using FileZilla or scp:
        scp devglobaljobs-changes.zip root@YOUR_VPS_IP:/tmp/

Step 2: SSH into your VPS:
        ssh root@YOUR_VPS_IP

Step 3: Extract and run:
        cd /tmp
        unzip devglobaljobs-changes.zip
        cd devglobaljobs-changes
        bash apply-changes.sh

That's it! The script will:
  - Update job limits to 500
  - Add Grow script to HTML
  - Apply professional CSS styling
  - Build the project (npm run build)
  - Restart PM2 automatically

ROLLBACK (if needed):
---------------------
  cp /var/www/devglobaljobs/server/storage.ts.bak /var/www/devglobaljobs/server/storage.ts
  cp /var/www/devglobaljobs/client/index.html.bak /var/www/devglobaljobs/client/index.html
  cd /var/www/devglobaljobs && npm run build && pm2 restart devglobaljobs

====================================================
