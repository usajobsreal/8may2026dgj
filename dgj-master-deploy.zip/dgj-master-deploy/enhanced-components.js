/**
 * DevGlobalJobs Enhanced Components
 * StatsBar, RecentlyViewed, MoreFromCompany, RelatedJobs,
 * ShareJob, SaveJob, JobAlert, nosnippet
 */
(function() {
  "use strict";

  var BASE = window.location.origin;
  var BLUE = '#2563eb';
  var DARK = '#1e293b';
  var GRAY = '#64748b';
  var LIGHT = '#f8fafc';
  var BORDER = '#e2e8f0';

  /* ── StatsBar ── */
  var StatsBar = {
    el: null,
    init: function() {
      var target = document.querySelector('[data-stats-bar]');
      if (!target) {
        var hero = document.querySelector('main') || document.getElementById('root');
        if (!hero) return;
        if (window.location.pathname !== '/' && window.location.pathname !== '') return;
        target = document.createElement('div');
        target.setAttribute('data-stats-bar', '');
        target.id = 'dgj-stats-bar';
        var firstSection = hero.querySelector('section') || hero.firstElementChild;
        if (firstSection && firstSection.nextSibling) {
          firstSection.parentNode.insertBefore(target, firstSection.nextSibling);
        } else {
          hero.appendChild(target);
        }
      }
      StatsBar.el = target;
      fetch(BASE + '/api/public-stats')
        .then(function(r) { return r.json(); })
        .then(function(d) { StatsBar.render(d); })
        .catch(function() {});
    },
    render: function(data) {
      if (!StatsBar.el) return;
      StatsBar.el.setAttribute('data-loaded', 'true');
      var items = [
        { label: 'Global Jobs', value: (data.totalJobs || 0).toLocaleString() },
        { label: 'Countries', value: (data.totalCountries || 180) + '+' },
        { label: 'Companies', value: (data.totalCompanies || 5000).toLocaleString() + '+' }
      ];
      StatsBar.el.innerHTML = items.map(function(item) {
        return '<div style="text-align:center;padding:8px 16px"><div style="font-size:1.5rem;font-weight:700;color:' + BLUE + '">' + item.value + '</div><div style="font-size:0.75rem;color:' + GRAY + '">' + item.label + '</div></div>';
      }).join('');
      StatsBar.el.style.display = 'flex';
      StatsBar.el.style.justifyContent = 'center';
      StatsBar.el.style.gap = '32px';
      StatsBar.el.style.padding = '16px 0';
    }
  };

  /* ── RecentlyViewed ── */
  var RecentlyViewed = {
    STORAGE_KEY: 'devglobaljobs_recently_viewed',
    MAX: 10,
    track: function(job) {
      if (!job || !job.id) return;
      var list = RecentlyViewed.getAll();
      list = list.filter(function(j) { return j.id !== job.id; });
      list.unshift({ id: job.id, title: job.title, org: job.organization, at: Date.now() });
      if (list.length > RecentlyViewed.MAX) list = list.slice(0, RecentlyViewed.MAX);
      try { localStorage.setItem(RecentlyViewed.STORAGE_KEY, JSON.stringify(list)); } catch(e) {}
    },
    getAll: function() {
      try {
        return JSON.parse(localStorage.getItem(RecentlyViewed.STORAGE_KEY) || '[]');
      } catch(e) { return []; }
    },
    render: function(container) {
      var items = RecentlyViewed.getAll();
      if (!items.length || !container) return;
      container.innerHTML = '<h3 style="font-size:1.1rem;font-weight:700;margin-bottom:12px;color:#7c3aed">Recently Viewed</h3>' +
        items.slice(0, 5).map(function(j) {
          return '<a href="/jobs/detail/' + j.id + '" style="display:block;padding:8px 12px;color:' + DARK + ';text-decoration:none;border-bottom:1px solid #f1f5f9;border-radius:6px;transition:background 0.2s" onmouseover="this.style.background=\'#f1f5f9\'" onmouseout="this.style.background=\'transparent\'"><span style="font-weight:500">' + (j.title || '') + '</span><span style="color:' + GRAY + ';font-size:0.8rem;margin-left:8px">' + (j.org || '') + '</span></a>';
        }).join('');
      container.style.cssText = 'padding:20px;border-radius:12px;background:white;border:1px solid ' + BORDER + ';margin-top:20px';
    }
  };

  /* ── RelatedJobs ── */
  var RelatedJobs = {
    fetch: function(jobId, limit) {
      return fetch(BASE + '/api/jobs/' + jobId + '/related?limit=' + (limit || 6))
        .then(function(r) { return r.json(); })
        .catch(function() { return []; });
    },
    render: function(container, jobs) {
      if (!container || !jobs || !jobs.length) return;
      container.innerHTML = '<h3 style="font-size:1.25rem;font-weight:700;margin-bottom:16px;color:#1e40af;display:flex;align-items:center;gap:8px"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#2563eb" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>Related Opportunities</h3>' +
        '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px">' +
        jobs.map(function(j) {
          return '<a href="/jobs/detail/' + j.id + '" style="display:block;padding:20px;border-radius:12px;background:white;text-decoration:none;border:1px solid ' + BORDER + ';transition:all 0.2s;box-shadow:0 1px 3px rgba(0,0,0,0.04)" onmouseover="this.style.boxShadow=\'0 8px 24px rgba(37,99,235,0.12)\';this.style.borderColor=\'#93c5fd\';this.style.transform=\'translateY(-2px)\'" onmouseout="this.style.boxShadow=\'0 1px 3px rgba(0,0,0,0.04)\';this.style.borderColor=\'' + BORDER + '\';this.style.transform=\'none\'">' +
            '<div style="font-weight:600;color:' + DARK + ';margin-bottom:6px;font-size:0.95rem;line-height:1.3">' + (j.title || '') + '</div>' +
            '<div style="font-size:0.85rem;color:' + GRAY + ';margin-bottom:8px">' + (j.organization || '') + '</div>' +
            '<div style="display:flex;gap:8px;flex-wrap:wrap">' +
            (j.location ? '<span style="display:inline-flex;align-items:center;gap:4px;font-size:0.75rem;color:' + GRAY + '"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>' + j.location + '</span>' : '') +
            (j.jobType ? '<span style="display:inline-block;padding:2px 10px;border-radius:999px;background:' + BLUE + ';color:white;font-size:0.7rem;font-weight:600">' + j.jobType + '</span>' : '') +
            '</div></a>';
        }).join('') + '</div>';
      container.style.cssText = 'padding:28px;border-radius:16px;background:linear-gradient(135deg,#f8fafc,#eff6ff);border:1px solid #dbeafe;margin-top:28px';
    }
  };

  /* ── MoreFromCompany ── */
  var MoreFromCompany = {
    fetch: function(jobId, limit) {
      return fetch(BASE + '/api/jobs/' + jobId + '/same-company?limit=' + (limit || 5))
        .then(function(r) { return r.json(); })
        .catch(function() { return []; });
    },
    render: function(container, jobs, orgName) {
      if (!container || !jobs || !jobs.length) return;
      container.innerHTML = '<h3 style="font-size:1.1rem;font-weight:700;margin-bottom:14px;color:#0f172a;display:flex;align-items:center;gap:8px"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2563eb" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>More from ' + (orgName || 'this company') + '</h3>' +
        jobs.map(function(j) {
          return '<a href="/jobs/detail/' + j.id + '" style="display:flex;align-items:center;padding:12px;text-decoration:none;border-bottom:1px solid #f1f5f9;border-radius:8px;transition:background 0.2s" onmouseover="this.style.background=\'#f8fafc\'" onmouseout="this.style.background=\'transparent\'">' +
            '<div style="flex:1"><div style="font-weight:500;color:' + DARK + ';font-size:0.9rem">' + (j.title || '') + '</div><div style="font-size:0.8rem;color:' + GRAY + ';margin-top:2px">' + (j.location || '') + '</div></div>' +
            '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>' +
          '</a>';
        }).join('');
      container.style.cssText = 'padding:20px;border-radius:12px;background:white;border:1px solid ' + BORDER + ';margin-top:20px';
    }
  };

  /* ── ShareJob ── */
  var ShareJob = {
    render: function(container, job) {
      if (!container || !job) return;
      var url = encodeURIComponent(BASE + '/jobs/detail/' + job.id);
      var title = encodeURIComponent((job.title || '') + ' at ' + (job.organization || ''));
      container.innerHTML =
        '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">' +
          '<span style="font-size:0.85rem;font-weight:600;color:#475569;margin-right:4px">Share this job:</span>' +
          '<a href="https://wa.me/?text=' + title + '%20' + url + '" target="_blank" rel="noopener nofollow sponsored" style="display:inline-flex;align-items:center;gap:4px;padding:8px 14px;border-radius:8px;background:#25d366;color:white;text-decoration:none;font-size:0.8rem;font-weight:600;transition:opacity 0.2s" onmouseover="this.style.opacity=\'0.9\'" onmouseout="this.style.opacity=\'1\'"><svg width="14" height="14" viewBox="0 0 24 24" fill="white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.625.846 5.059 2.284 7.034L.789 23.492l4.624-1.477A11.955 11.955 0 0 0 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22c-2.239 0-4.308-.724-5.992-1.953l-.43-.32-2.746.878.865-2.684-.345-.448A9.958 9.958 0 0 1 2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/></svg>WhatsApp</a>' +
          '<a href="https://www.linkedin.com/sharing/share-offsite/?url=' + url + '" target="_blank" rel="noopener nofollow sponsored" style="display:inline-flex;align-items:center;gap:4px;padding:8px 14px;border-radius:8px;background:#0077b5;color:white;text-decoration:none;font-size:0.8rem;font-weight:600;transition:opacity 0.2s" onmouseover="this.style.opacity=\'0.9\'" onmouseout="this.style.opacity=\'1\'"><svg width="14" height="14" viewBox="0 0 24 24" fill="white"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>LinkedIn</a>' +
          '<a href="https://twitter.com/intent/tweet?url=' + url + '&text=' + title + '" target="_blank" rel="noopener nofollow sponsored" style="display:inline-flex;align-items:center;gap:4px;padding:8px 14px;border-radius:8px;background:#1da1f2;color:white;text-decoration:none;font-size:0.8rem;font-weight:600;transition:opacity 0.2s" onmouseover="this.style.opacity=\'0.9\'" onmouseout="this.style.opacity=\'1\'"><svg width="14" height="14" viewBox="0 0 24 24" fill="white"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/></svg>Twitter</a>' +
          '<a href="mailto:?subject=' + title + '&body=Check%20this%20job:%20' + url + '" rel="nofollow" style="display:inline-flex;align-items:center;gap:4px;padding:8px 14px;border-radius:8px;background:#64748b;color:white;text-decoration:none;font-size:0.8rem;font-weight:600;transition:opacity 0.2s" onmouseover="this.style.opacity=\'0.9\'" onmouseout="this.style.opacity=\'1\'"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>Email</a>' +
          '<button onclick="navigator.clipboard.writeText(decodeURIComponent(\'' + url + '\'));this.textContent=\'Copied!\';var b=this;setTimeout(function(){b.innerHTML=\'<svg width=14 height=14 viewBox=\\\'0 0 24 24\\\' fill=none stroke=currentColor stroke-width=2><rect x=9 y=9 width=13 height=13 rx=2 ry=2/><path d=\\\'M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1\\\'/></svg> Copy Link\'},2000)" style="display:inline-flex;align-items:center;gap:4px;padding:8px 14px;border-radius:8px;background:#e2e8f0;color:#334155;border:none;cursor:pointer;font-size:0.8rem;font-weight:600;transition:all 0.2s" onmouseover="this.style.background=\'#cbd5e1\'" onmouseout="this.style.background=\'#e2e8f0\'"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>Copy Link</button>' +
        '</div>';
      container.style.cssText = 'padding:16px 20px;border-radius:12px;background:white;border:1px solid ' + BORDER + ';margin-top:16px';
    }
  };

  /* ── SaveJob ── */
  var SaveJob = {
    saved: {},
    init: function() {
      try {
        var s = JSON.parse(localStorage.getItem('devglobaljobs_saved') || '{}');
        SaveJob.saved = s;
      } catch(e) {}
    },
    toggle: function(jobId, btn) {
      if (SaveJob.saved[jobId]) {
        delete SaveJob.saved[jobId];
      } else {
        SaveJob.saved[jobId] = Date.now();
      }
      try { localStorage.setItem('devglobaljobs_saved', JSON.stringify(SaveJob.saved)); } catch(e) {}
      if (btn) SaveJob.updateBtn(btn, jobId);
    },
    updateBtn: function(btn, jobId) {
      var isSaved = !!SaveJob.saved[jobId];
      btn.innerHTML = isSaved ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="#ef4444" stroke="#ef4444" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg> Saved' : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg> Save Job';
      btn.style.color = isSaved ? '#ef4444' : GRAY;
      btn.style.borderColor = isSaved ? '#fecaca' : BORDER;
      btn.style.background = isSaved ? '#fef2f2' : 'white';
    },
    render: function(container, jobId) {
      if (!container) return;
      var btn = document.createElement('button');
      btn.style.cssText = 'display:inline-flex;align-items:center;gap:6px;background:white;border:1px solid ' + BORDER + ';border-radius:10px;padding:10px 18px;cursor:pointer;font-size:0.85rem;font-weight:600;transition:all 0.2s;width:100%';
      btn.onmouseover = function() { btn.style.borderColor = '#93c5fd'; };
      btn.onmouseout = function() { SaveJob.updateBtn(btn, jobId); };
      btn.onclick = function() { SaveJob.toggle(jobId, btn); };
      SaveJob.updateBtn(btn, jobId);
      container.appendChild(btn);
    }
  };

  /* ── JobAlert ── */
  var JobAlert = {
    render: function(container) {
      if (!container) return;
      container.innerHTML =
        '<div style="padding:24px;border-radius:16px;background:linear-gradient(135deg,#eff6ff,#faf5ff);border:1px solid #dbeafe">' +
          '<h3 style="font-size:1.1rem;font-weight:700;color:#1e40af;margin:0 0 8px 0;display:flex;align-items:center;gap:8px"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2563eb" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>Get Job Alerts</h3>' +
          '<p style="font-size:0.85rem;color:' + GRAY + ';margin:0 0 14px 0">Receive matching jobs directly in your inbox</p>' +
          '<form id="dgjAlertForm" style="display:flex;gap:8px;flex-wrap:wrap">' +
            '<input name="keyword" placeholder="Keywords (e.g. developer, UN)" style="flex:1;min-width:140px;padding:10px 14px;border:1px solid #d1d5db;border-radius:10px;font-size:0.85rem;outline:none;transition:border 0.2s" onfocus="this.style.borderColor=\'#2563eb\'" onblur="this.style.borderColor=\'#d1d5db\'" />' +
            '<select name="category" style="padding:10px 14px;border:1px solid #d1d5db;border-radius:10px;font-size:0.85rem;background:white">' +
              '<option value="">Any Category</option>' +
              '<option value="remote">Remote</option><option value="technology">Technology</option>' +
              '<option value="international">International</option><option value="un">UN</option>' +
              '<option value="ngo">NGO</option><option value="business">Business</option>' +
            '</select>' +
            '<button type="submit" style="padding:10px 24px;border-radius:10px;background:' + BLUE + ';color:white;border:none;cursor:pointer;font-weight:700;font-size:0.85rem;transition:opacity 0.2s" onmouseover="this.style.opacity=\'0.9\'" onmouseout="this.style.opacity=\'1\'">Subscribe</button>' +
          '</form>' +
        '</div>';
      var form = document.getElementById('dgjAlertForm');
      if (form) {
        form.onsubmit = function(e) {
          e.preventDefault();
          var fd = new FormData(form);
          fetch(BASE + '/api/job-alerts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ keyword: fd.get('keyword'), category: fd.get('category') })
          }).then(function(r) {
            if (r.ok) form.innerHTML = '<p style="color:#16a34a;font-weight:600;padding:8px 0">Alert created! You\'ll be notified of matching jobs.</p>';
            else form.innerHTML = '<p style="color:#dc2626;padding:8px 0">Please sign in to create job alerts.</p>';
          }).catch(function() {
            form.innerHTML = '<p style="color:#dc2626;padding:8px 0">Please sign in to create job alerts.</p>';
          });
        };
      }
    }
  };

  /* ── nosnippet utility ── */
  function applyNosnippet() {
    var els = document.querySelectorAll('[data-nosnippet], .nosnippet');
    els.forEach(function(el) {
      el.setAttribute('data-nosnippet', '');
    });
    var sensitive = document.querySelectorAll('.admin-panel, .internal-tools, [data-sensitive]');
    sensitive.forEach(function(el) {
      el.setAttribute('data-nosnippet', '');
    });
    if (window.location.pathname.match(/^\/jobs\/detail\//)) {
      var descEls = document.querySelectorAll('.prose, .job-description, [class*="description"], [class*="Description"]');
      descEls.forEach(function(el) {
        if (!el.closest('[data-nosnippet]') && el.textContent.length > 200) {
          el.setAttribute('data-nosnippet', '');
        }
      });
    }
    var externalLinks = document.querySelectorAll('a[target="_blank"]');
    externalLinks.forEach(function(link) {
      var href = link.getAttribute('href') || '';
      if (href && !href.includes('devglobaljobs.com') && !href.startsWith('/') && !href.startsWith('#')) {
        var rel = link.getAttribute('rel') || '';
        if (!rel.includes('nofollow')) {
          link.setAttribute('rel', 'nofollow sponsored noopener noreferrer');
        }
      }
    });
  }

  /* ── Find job detail main content area ── */
  function findJobContentArea() {
    var main = document.querySelector('main') || document.getElementById('root');
    if (!main) return null;
    var allDivs = main.querySelectorAll('div');
    var contentArea = null;
    for (var i = 0; i < allDivs.length; i++) {
      var d = allDivs[i];
      if (d.querySelector('h1, h2') && d.querySelector('a[href*="apply"], button')) {
        contentArea = d;
        break;
      }
    }
    return contentArea;
  }

  function getJobInfoFromPage() {
    var titleEl = document.querySelector('h1') || document.querySelector('h2');
    var title = titleEl ? titleEl.textContent.trim() : '';
    var orgEls = document.querySelectorAll('h1 + *, h2 + *, [class*="company"], [class*="org"]');
    var org = '';
    for (var i = 0; i < orgEls.length; i++) {
      var t = orgEls[i].textContent.trim();
      if (t && t.length < 100 && t !== title) { org = t; break; }
    }
    return { title: title, organization: org };
  }

  /* ── Auto-inject on job detail pages ── */
  function initJobDetail() {
    var match = window.location.pathname.match(/\/jobs\/detail\/(\d+)/);
    if (!match) return;
    var jobId = parseInt(match[1]);
    var jobInfo = getJobInfoFromPage();

    RecentlyViewed.track({ id: jobId, title: jobInfo.title, organization: jobInfo.organization });
    fetch(BASE + '/api/jobs/' + jobId + '/views', { method: 'POST' }).catch(function(){});

    var root = document.getElementById('root');
    if (!root) return;

    var footer = document.querySelector('footer');
    var insertBefore = footer || null;
    var parentForInsert = footer ? footer.parentNode : root;

    var relatedSection = document.createElement('div');
    relatedSection.id = 'dgj-related-section';

    var companySection = document.createElement('div');
    companySection.id = 'dgj-company-section';

    var recentSection = document.createElement('div');
    recentSection.id = 'dgj-recent-section';

    var alertSection = document.createElement('div');
    alertSection.id = 'dgj-alert-section';
    alertSection.style.cssText = 'margin-top:20px';
    JobAlert.render(alertSection);

    var bottomShare = document.createElement('div');
    bottomShare.id = 'dgj-share-section';
    ShareJob.render(bottomShare, { id: jobId, title: jobInfo.title, organization: jobInfo.organization });

    var wrapper = document.createElement('div');
    wrapper.id = 'dgj-enhanced-sections';
    wrapper.style.cssText = 'max-width:1200px;margin:0 auto;padding:0 16px 40px 16px';
    wrapper.appendChild(bottomShare);
    wrapper.appendChild(relatedSection);
    wrapper.appendChild(companySection);
    wrapper.appendChild(recentSection);
    wrapper.appendChild(alertSection);

    if (insertBefore) {
      parentForInsert.insertBefore(wrapper, insertBefore);
    } else {
      parentForInsert.appendChild(wrapper);
    }

    RelatedJobs.fetch(jobId, 6).then(function(jobs) {
      RelatedJobs.render(relatedSection, jobs);
    });

    MoreFromCompany.fetch(jobId, 5).then(function(jobs) {
      MoreFromCompany.render(companySection, jobs, jobInfo.organization);
    });

    RecentlyViewed.render(recentSection);
  }

  /* ── Boot ── */
  function boot() {
    SaveJob.init();
    applyNosnippet();

    if (document.querySelector('#dgj-enhanced-sections')) return;

    /* StatsBar disabled - React app has built-in stats section */

    if (/\/jobs\/detail\/\d+/.test(window.location.pathname)) {
      initJobDetail();
    }
  }

  function waitForContent() {
    var attempts = 0;
    var interval = setInterval(function() {
      attempts++;
      var hasContent = document.querySelector('h1, h2, [class*="job"]');
      if (hasContent || attempts > 20) {
        clearInterval(interval);
        boot();
      }
    }, 250);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() { setTimeout(waitForContent, 300); });
  } else {
    setTimeout(waitForContent, 300);
  }

  var lastPath = window.location.pathname;
  setInterval(function() {
    if (window.location.pathname !== lastPath) {
      lastPath = window.location.pathname;
      setTimeout(function() {
        var old = document.getElementById('dgj-enhanced-sections');
        if (old) old.remove();
        var oldStats = document.getElementById('dgj-stats-bar');
        if (oldStats) oldStats.remove();
        boot();
      }, 500);
    }
  }, 500);

  window.__DGJ = {
    StatsBar: StatsBar,
    RecentlyViewed: RecentlyViewed,
    RelatedJobs: RelatedJobs,
    MoreFromCompany: MoreFromCompany,
    ShareJob: ShareJob,
    SaveJob: SaveJob,
    JobAlert: JobAlert,
    nosnippet: applyNosnippet
  };
})();
