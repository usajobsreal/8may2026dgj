#!/bin/bash
set -e
APP="/var/www/devglobaljobs"
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "=============================================="
echo "  DevGlobalJobs - MASTER DEPLOY v8"
echo "  All changes in one go — website stays live"
echo "=============================================="
cd "$APP"

# ── 1. JOBS LIMIT → 500 ──────────────────────────────────────
echo "[1/6] Setting jobs limit to 500..."
cp server/storage.ts server/storage.ts.bak 2>/dev/null || true
sed -i 's/\.limit([0-9]\+)/\.limit(500)/g' server/storage.ts
echo "      ✓ Limits updated:"
grep -n "\.limit([0-9]" server/storage.ts | grep -v "\.limit(1)" | head -5

# ── 2. GROW SCRIPT ───────────────────────────────────────────
echo "[2/6] Adding Grow script to index.html..."
cp client/index.html client/index.html.bak 2>/dev/null || true
if ! grep -q "grow.me" client/index.html; then
  sed -i 's|</head>|  <script data-grow-initializer="">!(function(){window.growMe||((window.growMe=function(e){window.growMe._.push(e);}),(window.growMe._=[]));var e=document.createElement("script");(e.type="text/javascript"),(e.src="https://faves.grow.me/main.js"),(e.defer=!0),e.setAttribute("data-grow-faves-site-id","U2l0ZTplNDkyZjZlMS01YTcyLTQzMjYtYThhNC0xNzQyOTI4YmVkOWE=");var t=document.getElementsByTagName("script")[0];t.parentNode.insertBefore(e,t);})();</script>\n</head>|' client/index.html
  echo "      ✓ Grow script added"
else
  echo "      ✓ Grow script already present"
fi

# ── 3. CSS OVERRIDES (Google Auth + NGO Banner) ───────────────
echo "[3/6] Applying professional CSS overrides..."
mkdir -p client/src/styles
cat > client/src/styles/custom-overrides.css << 'CSSEOF'
/* DevGlobalJobs - Professional UI Overrides */
/* Google Sign-In Button */
a[href="/api/auth/google"], a[data-testid="btn-signin"], a[data-testid="mobile-signin"] {
  display:inline-flex !important; align-items:center !important; gap:8px !important;
  padding:9px 18px !important; font-size:14px !important; font-weight:500 !important;
  border:1.5px solid #dadce0 !important; border-radius:8px !important;
  background:#ffffff !important; color:#3c4043 !important;
  box-shadow:0 1px 4px rgba(0,0,0,0.10) !important; cursor:pointer !important;
  transition:all 0.18s ease !important; text-decoration:none !important;
}
a[href="/api/auth/google"]:hover, a[data-testid="btn-signin"]:hover {
  background:#f1f3f4 !important; box-shadow:0 2px 10px rgba(0,0,0,0.14) !important;
}
/* NGO Free Posting Banner - theme matched */
section[class*="ngo"], div[class*="ngo-banner"], div[class*="free-post"],
[data-section="ngo-free"], .ngo-posting-banner {
  background:linear-gradient(135deg,hsl(var(--primary)) 0%,hsl(var(--primary)/.80) 100%) !important;
  border-radius:16px !important; padding:32px 40px !important;
  color:#fff !important; box-shadow:0 6px 28px hsl(var(--primary)/.22) !important;
  border:none !important; position:relative !important; overflow:hidden !important;
}
[data-section="ngo-free"] *, .ngo-posting-banner * { color:#fff !important; }
[data-section="ngo-free"] button, [data-section="ngo-free"] a,
.ngo-posting-banner button, .ngo-posting-banner a {
  background:rgba(255,255,255,.15) !important; border:1.5px solid rgba(255,255,255,.65) !important;
  border-radius:8px !important; padding:10px 26px !important; font-weight:600 !important;
  backdrop-filter:blur(4px) !important; transition:background .2s !important;
}
CSSEOF
# Import CSS at top of index.css
sed -i '/@import.*custom-overrides/d' client/src/index.css
sed -i '1i @import "./styles/custom-overrides.css";' client/src/index.css
echo "      ✓ CSS overrides applied"

# ── 4. SIGN IN BUTTON IN HEADER ──────────────────────────────
echo "[4/6] Adding Sign In button to navbar..."
node "$DIR/patch-signin.js"

# ── 5. COPY ENHANCED JS FILES ─────────────────────────────────
echo "[5/6] Installing enhanced UI components..."
if [ -f "$DIR/enhanced-v7.js" ]; then
  mkdir -p dist/public/assets
  cp "$DIR/enhanced-v7.js" dist/public/assets/enhanced-v7.js
  cp "$DIR/enhanced-components.js" dist/public/assets/enhanced-components.js 2>/dev/null || true
  # Inject into built index.html if not already there
  if ! grep -q "enhanced-v7" dist/public/index.html 2>/dev/null; then
    sed -i "s|</body>|  <script>(function(){var s=document.createElement('script');s.src='/assets/enhanced-v7.js';document.body.appendChild(s);})();</script>\n</body>|" dist/public/index.html 2>/dev/null || true
  fi
  echo "      ✓ Enhanced JS components installed"
fi

# ── 6. BUILD + RESTART ────────────────────────────────────────
echo "[6/6] Building and restarting (website stays up during build)..."
npm run build
pm2 restart devglobaljobs

echo ""
echo "=============================================="
echo "  ALL DONE! devglobaljobs.com is updated"
echo "  Changes applied:"
echo "  ✓ Jobs limit → 500"
echo "  ✓ Grow script active"
echo "  ✓ Google Sign In button in navbar"
echo "  ✓ Professional CSS (Auth + NGO Banner)"
echo "  ✓ Enhanced UI components"
echo "  PM2 Status:"
pm2 list | grep devglobaljobs
echo "=============================================="
