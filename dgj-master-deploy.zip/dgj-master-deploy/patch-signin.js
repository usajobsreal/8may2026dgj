#!/usr/bin/env node
/**
 * DevGlobalJobs - Add Sign In Button to Header + Google OAuth Routes
 */

const fs = require('fs');
const path = require('path');

const APP = '/var/www/devglobaljobs';

// ─── 1. PATCH HEADER.TSX ─────────────────────────────────────────────────────

const headerPath = path.join(APP, 'client/src/components/header.tsx');
let header = fs.readFileSync(headerPath, 'utf8');

// Add UserCircle, LogIn imports from lucide-react if not present
if (!header.includes('UserCircle') && !header.includes('LogIn')) {
  header = header.replace(
    /import \{ Briefcase, Menu, X,/,
    'import { Briefcase, Menu, X, UserCircle, LogIn,'
  );
  console.log('✓ Added UserCircle, LogIn imports');
}

// Add user query after existing queries (after countryStats query)
if (!header.includes('/api/auth/user')) {
  header = header.replace(
    `const { data: countryStats }`,
    `const { data: currentUser } = useQuery<{ id: number; name: string; email: string; picture?: string } | null>({
    queryKey: ["/api/auth/user"],
    retry: false,
  });

  const { data: countryStats }`
  );
  console.log('✓ Added user auth query');
}

// Add Sign In button in desktop nav (after ThemeToggle, before mobile menu button)
if (!header.includes('data-testid="btn-signin"')) {
  header = header.replace(
    `            <ThemeToggle />
            <Button
              size="icon"
              variant="ghost"
              className="lg:hidden"
              onClick={() => setMobileOpen(!mobileOpen)}`,
    `            <ThemeToggle />
            {currentUser ? (
              <div className="relative group hidden lg:flex items-center">
                <button
                  className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-accent transition-colors"
                  data-testid="btn-user-profile"
                >
                  {currentUser.picture ? (
                    <img src={currentUser.picture} alt={currentUser.name} className="w-7 h-7 rounded-full object-cover ring-2 ring-primary/20" />
                  ) : (
                    <UserCircle className="w-7 h-7 text-muted-foreground" />
                  )}
                  <span className="text-sm font-medium hidden xl:block max-w-[120px] truncate">{currentUser.name?.split(' ')[0]}</span>
                </button>
                <div className="absolute top-full right-0 mt-1 w-52 bg-popover border border-border rounded-lg shadow-xl py-1 z-50 hidden group-hover:block">
                  <div className="px-4 py-3 border-b border-border">
                    <p className="text-sm font-semibold truncate">{currentUser.name}</p>
                    <p className="text-xs text-muted-foreground truncate">{currentUser.email}</p>
                  </div>
                  <a href="/post-job" className="flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-accent transition-colors">
                    <Briefcase className="h-4 w-4 text-muted-foreground" />Post a Job
                  </a>
                  <a href="/api/auth/logout" className="flex items-center gap-2 px-4 py-2.5 text-sm text-destructive hover:bg-accent transition-colors">
                    <LogIn className="h-4 w-4" />Sign Out
                  </a>
                </div>
              </div>
            ) : (
              <a href="/api/auth/google" className="hidden lg:flex items-center gap-2 px-3 py-1.5 text-sm font-medium border border-border rounded-lg bg-background hover:bg-accent transition-all shadow-sm" data-testid="btn-signin">
                <svg className="w-4 h-4" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
                Sign In
              </a>
            )}
            <Button
              size="icon"
              variant="ghost"
              className="lg:hidden"
              onClick={() => setMobileOpen(!mobileOpen)}`
  );
  console.log('✓ Added Sign In / Profile button to desktop nav');
}

// Add Sign In to mobile menu (before closing nav)
if (!header.includes('mobile-signin')) {
  header = header.replace(
    `          <div className="border-t border-border mt-3 pt-3">
            <Link href="/blog" onClick={closeMobile}>`,
    `          <div className="border-t border-border mt-3 pt-3">
            {currentUser ? (
              <div className="px-3 py-2">
                <div className="flex items-center gap-3 mb-2 p-2 bg-accent rounded-lg">
                  {currentUser.picture ? (
                    <img src={currentUser.picture} alt={currentUser.name} className="w-9 h-9 rounded-full object-cover" />
                  ) : (
                    <UserCircle className="w-9 h-9 text-muted-foreground" />
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate">{currentUser.name}</p>
                    <p className="text-xs text-muted-foreground truncate">{currentUser.email}</p>
                  </div>
                </div>
                <a href="/api/auth/logout" className="flex w-full items-center gap-2 px-3 py-2 text-sm text-destructive rounded-md hover:bg-accent" data-testid="mobile-signout">
                  <LogIn className="h-4 w-4" />Sign Out
                </a>
              </div>
            ) : (
              <a href="/api/auth/google" className="flex items-center justify-center gap-2 mx-3 my-2 py-2.5 text-sm font-medium border border-border rounded-lg bg-background hover:bg-accent transition-all" data-testid="mobile-signin">
                <svg className="w-4 h-4" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
                Sign in with Google
              </a>
            )}
            <Link href="/blog" onClick={closeMobile}>`
  );
  console.log('✓ Added Sign In / Profile to mobile menu');
}

fs.writeFileSync(headerPath, header);
console.log('✓ header.tsx saved');

// ─── 2. PATCH SERVER ROUTES - Add auth endpoints ──────────────────────────────

const routesPath = path.join(APP, 'server/routes.ts');
let routes = fs.readFileSync(routesPath, 'utf8');

if (!routes.includes('/api/auth/user')) {
  // Find a good place to insert - after imports, before first app.get
  const authRoutes = `
  // ─── Google OAuth & User Auth ──────────────────────────────────────
  app.get("/api/auth/user", (req, res) => {
    if (req.session && (req.session as any).user) {
      res.json((req.session as any).user);
    } else {
      res.json(null);
    }
  });

  app.get("/api/auth/google", (req, res) => {
    const clientId = process.env.GOOGLE_CLIENT_ID;
    if (!clientId) {
      return res.status(503).json({ message: "Google OAuth not configured. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET." });
    }
    const redirectUri = encodeURIComponent(\`\${req.protocol}://\${req.get('host')}/api/auth/google/callback\`);
    const scope = encodeURIComponent("openid email profile");
    const url = \`https://accounts.google.com/o/oauth2/v2/auth?client_id=\${clientId}&redirect_uri=\${redirectUri}&response_type=code&scope=\${scope}&access_type=online\`;
    res.redirect(url);
  });

  app.get("/api/auth/google/callback", async (req, res) => {
    try {
      const { code } = req.query;
      if (!code) return res.redirect("/?error=no_code");

      const clientId = process.env.GOOGLE_CLIENT_ID!;
      const clientSecret = process.env.GOOGLE_CLIENT_SECRET!;
      const redirectUri = \`\${req.protocol}://\${req.get('host')}/api/auth/google/callback\`;

      // Exchange code for tokens
      const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ code: code as string, client_id: clientId, client_secret: clientSecret, redirect_uri: redirectUri, grant_type: "authorization_code" }),
      });
      const tokens = await tokenRes.json() as any;
      if (!tokens.access_token) return res.redirect("/?error=token_failed");

      // Get user info
      const userRes = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
        headers: { Authorization: \`Bearer \${tokens.access_token}\` },
      });
      const googleUser = await userRes.json() as any;

      // Store in session
      (req.session as any).user = {
        id: googleUser.id,
        name: googleUser.name,
        email: googleUser.email,
        picture: googleUser.picture,
      };

      // Redirect to previous page or home
      const returnTo = (req.session as any).returnTo || "/";
      delete (req.session as any).returnTo;
      res.redirect(returnTo);
    } catch (e) {
      console.error("Google OAuth error:", e);
      res.redirect("/?error=oauth_failed");
    }
  });

  app.get("/api/auth/logout", (req, res) => {
    req.session.destroy(() => {
      res.redirect("/");
    });
  });
  // ─────────────────────────────────────────────────────────────────────

`;

  // Insert before first route registration
  routes = routes.replace(
    /(\s*app\.get\("\/api\/jobs\/all"/),
    authRoutes + '$1'
  );
  fs.writeFileSync(routesPath, routes);
  console.log('✓ Auth routes added to server/routes.ts');
} else {
  console.log('✓ Auth routes already exist');
}

console.log('\n✅ All patches applied! Now run: cd /var/www/devglobaljobs && npm run build && pm2 restart devglobaljobs');
