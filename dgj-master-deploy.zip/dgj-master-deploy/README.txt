====================================================
  DevGlobalJobs - MASTER DEPLOY PACKAGE
  All changes: Sign In, NGO Banner, Jobs 500, Grow
====================================================

HOW TO DEPLOY ON VPS:
---------------------
Step 1: Upload this ZIP to GitHub (usajobsreal/8may2026dgj)

Step 2: On VPS run this ONE command:
  cd /tmp && curl -sL https://raw.githubusercontent.com/usajobsreal/8may2026dgj/main/dgj-master-deploy.zip -o m.zip && python3 -c "import zipfile;zipfile.ZipFile('m.zip').extractall('.')" && bash dgj-master-deploy/master-deploy.sh

WHAT IT DOES:
  1. Jobs limit -> 500 (Featured + All Jobs)
  2. Grow Installation Script added
  3. Sign In with Google button in navbar
  4. Professional CSS (Google Auth box + NGO Banner)
  5. Enhanced UI components (StatsBar, SaveJob, etc.)
  6. Build + PM2 restart (website never goes down)

FOR GOOGLE OAUTH (Sign In to actually work):
  - Go to console.cloud.google.com
  - Create OAuth 2.0 credentials
  - Add redirect: https://devglobaljobs.com/api/auth/google/callback
  - Then on VPS:
    echo "GOOGLE_CLIENT_ID=xxxx" >> /var/www/devglobaljobs/.env
    echo "GOOGLE_CLIENT_SECRET=xxxx" >> /var/www/devglobaljobs/.env
    pm2 restart devglobaljobs
====================================================