#!/bin/bash

# ============================================================
# DevGlobalJobs - Apply Changes Script
# Run as: bash apply-changes.sh
# Location: /var/www/devglobaljobs/
# ============================================================

set -e

APP_DIR="/var/www/devglobaljobs"
echo "=============================="
echo " DevGlobalJobs - Applying Changes"
echo "=============================="

cd "$APP_DIR"

# ============================================================
# CHANGE 1: Jobs Limit - Featured Jobs & All Jobs → 500
# ============================================================
echo ""
echo "[1/4] Updating job limits to 500..."

# Backup storage.ts
cp server/storage.ts server/storage.ts.bak

# Change all .limit(20) and .limit(30) in storage.ts to .limit(500)
sed -i 's/\.limit(20)/\.limit(500)/g' server/storage.ts
sed -i 's/\.limit(30)/\.limit(500)/g' server/storage.ts

echo "      storage.ts limits updated:"
grep -n "limit(500)\|limit(20)\|limit(30)" server/storage.ts || echo "      (verify manually)"

# ============================================================
# CHANGE 2: Add Grow Installation Script to index.html
# ============================================================
echo ""
echo "[2/4] Adding Grow script to client/index.html..."

# Backup index.html
cp client/index.html client/index.html.bak

# Check if Grow script already exists
if grep -q "grow.me" client/index.html; then
  echo "      Grow script already present, skipping."
else
  # Insert Grow script before closing </head> tag
  sed -i 's|</head>|    <script data-grow-initializer="">!(function(){window.growMe||((window.growMe=function(e){window.growMe._.push(e);}),(window.growMe._=[]));var e=document.createElement("script");(e.type="text/javascript"),(e.src="https://faves.grow.me/main.js"),(e.defer=!0),e.setAttribute("data-grow-faves-site-id","U2l0ZTplNDkyZjZlMS01YTcyLTQzMjYtYThhNC0xNzQyOTI4YmVkOWE=");var t=document.getElementsByTagName("script")[0];t.parentNode.insertBefore(e,t);})();</script>\n</head>|' client/index.html
  echo "      Grow script added successfully."
fi

# ============================================================
# CHANGE 3: Google Auth & Profile UI - Professional Styling
# ============================================================
echo ""
echo "[3/4] Applying professional Google Auth & NGO Banner styles..."

# Create styles directory if it doesn't exist
mkdir -p client/src/styles

# Create a custom CSS file for overrides
cat > client/src/styles/custom-overrides.css << 'CSSEOF'
/* ============================================================
   DevGlobalJobs - Professional UI Overrides
   Google Auth Sign-In Box + NGO Free Posting Banner
   ============================================================ */

/* ---- Google Sign-In Button - Professional International Style ---- */
.google-signin-btn,
button[class*="google"],
a[class*="google-login"],
.auth-google-btn,
[data-provider="google"] {
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  gap: 10px !important;
  width: 100% !important;
  padding: 12px 20px !important;
  border: 1.5px solid #dadce0 !important;
  border-radius: 8px !important;
  background: #ffffff !important;
  color: #3c4043 !important;
  font-family: 'Google Sans', Roboto, Arial, sans-serif !important;
  font-size: 15px !important;
  font-weight: 500 !important;
  letter-spacing: 0.01em !important;
  cursor: pointer !important;
  transition: background 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease !important;
  box-shadow: 0 1px 3px rgba(0,0,0,0.08) !important;
  text-decoration: none !important;
}

.google-signin-btn:hover,
button[class*="google"]:hover,
a[class*="google-login"]:hover,
.auth-google-btn:hover,
[data-provider="google"]:hover {
  background: #f8f9fa !important;
  box-shadow: 0 2px 8px rgba(0,0,0,0.15) !important;
  border-color: #c6c6c6 !important;
}

/* Auth Modal / Sign-In Box Container */
.auth-modal,
.signin-modal,
.login-modal,
[class*="auth-container"],
[class*="signin-container"] {
  border-radius: 16px !important;
  box-shadow: 0 8px 40px rgba(0,0,0,0.18) !important;
  overflow: hidden !important;
}

/* Auth form header */
.auth-modal h2,
.auth-modal h3,
.signin-modal h2,
.signin-modal h3 {
  font-size: 22px !important;
  font-weight: 700 !important;
  text-align: center !important;
  letter-spacing: -0.3px !important;
}

/* Divider "or" line */
.auth-divider,
[class*="or-divider"] {
  display: flex !important;
  align-items: center !important;
  gap: 12px !important;
  color: #9ca3af !important;
  font-size: 13px !important;
  font-weight: 500 !important;
  margin: 16px 0 !important;
}

.auth-divider::before,
.auth-divider::after,
[class*="or-divider"]::before,
[class*="or-divider"]::after {
  content: "" !important;
  flex: 1 !important;
  height: 1px !important;
  background: #e5e7eb !important;
}

/* ---- NGO Free Posting Banner - Theme Matched ---- */
.ngo-banner,
[class*="ngo-banner"],
[class*="ngo-free"],
[id*="ngo-banner"],
.free-posting-banner {
  background: linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--primary) / 0.85) 100%) !important;
  border-radius: 16px !important;
  padding: 28px 36px !important;
  color: #ffffff !important;
  box-shadow: 0 4px 24px hsl(var(--primary) / 0.25) !important;
  border: none !important;
  position: relative !important;
  overflow: hidden !important;
}

.ngo-banner::before,
[class*="ngo-banner"]::before,
.free-posting-banner::before {
  content: "" !important;
  position: absolute !important;
  top: -40px !important;
  right: -40px !important;
  width: 160px !important;
  height: 160px !important;
  border-radius: 50% !important;
  background: rgba(255,255,255,0.08) !important;
  pointer-events: none !important;
}

.ngo-banner h2,
.ngo-banner h3,
.ngo-banner p,
[class*="ngo-banner"] h2,
[class*="ngo-banner"] h3,
[class*="ngo-banner"] p,
.free-posting-banner h2,
.free-posting-banner h3,
.free-posting-banner p {
  color: #ffffff !important;
}

.ngo-banner button,
.ngo-banner a,
[class*="ngo-banner"] button,
[class*="ngo-banner"] a,
.free-posting-banner button,
.free-posting-banner a {
  background: rgba(255,255,255,0.15) !important;
  border: 1.5px solid rgba(255,255,255,0.6) !important;
  color: #ffffff !important;
  border-radius: 8px !important;
  padding: 10px 24px !important;
  font-weight: 600 !important;
  transition: background 0.2s ease !important;
  backdrop-filter: blur(4px) !important;
}

.ngo-banner button:hover,
.ngo-banner a:hover,
[class*="ngo-banner"] button:hover,
[class*="ngo-banner"] a:hover,
.free-posting-banner button:hover,
.free-posting-banner a:hover {
  background: rgba(255,255,255,0.28) !important;
}

/* ---- Job Posting Form - Professional Auth-Required Dialog ---- */
.post-job-auth-prompt,
[class*="post-job-login"],
[class*="employer-login"] {
  background: linear-gradient(145deg, #f8faff 0%, #fff 100%) !important;
  border: 1px solid hsl(var(--border)) !important;
  border-radius: 16px !important;
  padding: 32px !important;
  text-align: center !important;
  box-shadow: 0 4px 20px rgba(0,0,0,0.08) !important;
}

CSSEOF

echo "      custom-overrides.css created."

# Import it into main CSS or check if there's an existing global import
MAIN_CSS=$(find client/src -name "index.css" -o -name "global.css" -o -name "globals.css" 2>/dev/null | head -1)
if [ -n "$MAIN_CSS" ]; then
  if ! grep -q "custom-overrides" "$MAIN_CSS"; then
    echo '@import "./styles/custom-overrides.css";' >> "$MAIN_CSS"
    echo "      Imported into $MAIN_CSS"
  else
    echo "      Already imported in $MAIN_CSS"
  fi
else
  echo "      NOTE: Manually import 'custom-overrides.css' in your main CSS file."
fi

# ============================================================
# CHANGE 4: Build & Restart
# ============================================================
echo ""
echo "[4/4] Building project and restarting PM2..."

npm run build

pm2 restart devglobaljobs

echo ""
echo "=============================="
echo " All changes applied!"
echo " Verification:"
grep -n "limit(500)" server/storage.ts | head -5
echo " Grow script in index.html:"
grep -c "grow.me" client/index.html && echo " lines found"
echo "=============================="
echo " Site is live at: https://devglobaljobs.com"
echo "=============================="
